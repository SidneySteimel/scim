<?php
if (empty($_POST)){
       
}
else {

$mail = $_POST["HWR-Mail"] . "\r\n";

file_put_contents("Mail/it_2015_mails.txt", $mail, FILE_APPEND);
}
echo "hallo";
 ?>
window.onload = function () {
   
    var myForm = document.getElementById("scimForm");
    myForm.onsubmit = function () {
        var course = document.getElementById("form_tt_course");
        var selectedcourse = course.options[course.selectedIndex].text;

        var facultyid = document.getElementById("form_tt_faculty");
        var selectedfaculty = facultyid.options[facultyid.selectedIndex].text;
        
       
      
        var stringconfrim = ("Möchtest du den folgenden Kurs abonnieren?\nFachrichtung: " + selectedfaculty + "\nKurs: "+ selectedcourse);
          
        return confirm(stringconfrim);
      
         
        
    };
  
};

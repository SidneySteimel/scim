<!DOCTYPE html>
<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>ipool</title>
<link rel="stylesheet" type="text/css" href="css/default.css">
<!--[if IE 6]>
<link rel="stylesheet" type="text/css" href="css/ie6.css">
<![endif]-->
<!--[if IE 7]>
<link rel="stylesheet" type="text/css" href="css/ie7.css">
<![endif]-->
    <script type="text/javascript">
function on_faculty_change() {
    if (document.timetable.faculty.selectedIndex > 0) {
        var fac = document.timetable.faculty.options[document.timetable.faculty.selectedIndex].value;
    	window.location.href = 'main.php?action=browse_stundenplaene&faculty='+fac;
    }
}

function on_course_change() {
    if ((document.timetable.faculty.selectedIndex > 0) && (document.timetable.course.selectedIndex > 0)) {
        var fac = document.timetable.faculty.options[document.timetable.faculty.selectedIndex].value;
        var crs = document.timetable.course.options[document.timetable.course.selectedIndex].value;
    	window.location.href = 'main.php?action=browse_stundenplaene&faculty='+fac+'&course='+crs;
    }
}
</script></head>
<body>
<div id="header">
    <a href="http://www.hwr-berlin.de" target="_blank"><img id="logo" src="gfx/hwr_logo.gif" width="249" height="57" alt=""></a>
    <h1>
        <a href="/main.php?menufb=0&amp;menukid=0&amp;menusem=0&amp;menuvl=0">iPool</a>
    </h1>
    <div id="top_nav">
        <div id="search">
            <form action="/main.php" method="GET">
                <label for="search_string">Suchen:</label> <span><input id="search_string"
                    name="qry"> <input type="hidden" name="action"
                    value="search_documents"> <input type="image" src="gfx/magnifier_icon.png"
                    alt="Suchen"> </span>
            </form>
        </div>
        <ul>
            <li><a href="/main.php?action=browse_stundenplaene"><img style="vertical-align:middle;" src="gfx/icon_calendar.png" > Stundenpl&auml;ne</a></li>
            <li><a href="/main.php?action=contact"><img style="vertical-align:middle;" src="gfx/icon_letter.png" > Kontakt</a></li>
            <li><a href="/main.php?action=help"><img style="vertical-align:middle;" src="gfx/icon_help.png" > Hilfe</a></li>
            <li><a href="/main.php?action=logout"><img style="vertical-align:middle;" src="gfx/icon_logoff.png"> Logout</a> (angemeldet als:<em> <a href=/main.php?action=special>student</a></em>)</li>
        </ul>
    </div>
</div>
    <div id="page">
    <div id="nav">
        <!-- Navigationsmenü -->
    <div class="container">
<h2><A HREF="/main.php?menufb=0&amp;menukid=0&amp;menusem=0&amp;menuvl=0">Fachrichtungen</A></h2>
<div class="container_content">
<ul>
<li><A HREF="/main.php?menufb=15&amp;menukid=1&amp;menusem=0&amp;menuvl=0">Allgemein</A></li>
<li><A HREF="/main.php?menufb=17&amp;menukid=1&amp;menusem=0&amp;menuvl=0">BA weite VL'gen</A></li>
<li><A HREF="/main.php?menufb=1&amp;menukid=0&amp;menusem=0&amp;menuvl=0">Bank</A></li>
<li><A HREF="/main.php?menufb=2&amp;menukid=1&amp;menusem=0&amp;menuvl=0">Bauwesen</A></li>
<li><A HREF="/main.php?menufb=16&amp;menukid=1&amp;menusem=0&amp;menuvl=0">Dienstleistungsm.</A></li>
<li><A HREF="/main.php?menufb=18&amp;menukid=1&amp;menusem=0&amp;menuvl=0">Elektrotechnik</A></li>
<li><A HREF="/main.php?menufb=3&amp;menukid=0&amp;menusem=0&amp;menuvl=0">Handel</A></li>
<li><A HREF="/main.php?menufb=4&amp;menukid=0&amp;menusem=0&amp;menuvl=0">Immobilien</A></li>
<li><A HREF="/main.php?menufb=5&amp;menukid=0&amp;menusem=0&amp;menuvl=0">Industrie</A></li>
<li><A HREF="/main.php?menufb=6&amp;menukid=1&amp;menusem=0&amp;menuvl=0">Informatik</A></li>
<li><A HREF="/main.php?menufb=13&amp;menukid=1&amp;menusem=0&amp;menuvl=0">Internat. Studiengang</A></li>
<li><A HREF="/main.php?menufb=7&amp;menukid=1&amp;menusem=0&amp;menuvl=0">Maschinenbau</A></li>
<li><A HREF="/main.php?menufb=8&amp;menukid=1&amp;menusem=0&amp;menuvl=0">Spedition / Logistik</A></li>
<li><A HREF="/main.php?menufb=9&amp;menukid=0&amp;menusem=0&amp;menuvl=0">Steuern</A></li>
<li><A HREF="/main.php?menufb=14&amp;menukid=1&amp;menusem=0&amp;menuvl=0">Techn. Facility Management</A></li>
<li><A HREF="/main.php?menufb=10&amp;menukid=0&amp;menusem=0&amp;menuvl=0">Tourismus</A></li>
<li><A HREF="/main.php?menufb=11&amp;menukid=0&amp;menusem=0&amp;menuvl=0">Versicherung</A></li>
<li><A HREF="/main.php?menufb=12&amp;menukid=0&amp;menusem=0&amp;menuvl=0">Wirtschaftsinformatik</A></li>
</ul></div>
</div>
<div class="container">
<h2>Allgemeines</h2>
<div class="container_content">
<ul>
<li class="active"><A HREF="/main.php?action=browse_stundenplaene">Stundenpl&auml;ne</A></li>
<li><A HREF="/main.php?action=browse_polls">Umfragen</A></li>
<li><A HREF="/main.php?action=mail_authorize">Mailbenachrichtigungen</A></li>
<li><a href="http://ipool.ba-berlin.de/bawiki" target="_blank">Ba-Wiki</a></li><li><a href="/main.php?action=search_documents&amp;mode=advanced">Dokumentensuche</a></li></ul>
</div>
</div>
</div>
<div class="content large">
    <div class="container">
        <h2>Stundenpl&auml;ne</h2>
        <div class="container_content">
            <noscript>
                <p class="error">Bitte aktiviere JavaScript f&uuml;r die Stundenplanauswahl!</p>
            </noscript>
            <p>Unter [Allgemein] [Studiendekanat] [Informationen des
                Studiendekanats] kannst du dir eine <a href="http://ipool.ba-berlin.de/main.php?action=detailview&fileno=28516&menufb=15&menukid=1&menusem=10&menuvl=1083">
                Erweiterung f&uuml;r die &Uuml;bernahme der Termine (ics-Files) in den Outlook
                Kalender herunterladen</a>.</p>
            <p><strong>Neu:</strong> Ab sofort steht dir auch eine mobile Version deines Stundenplans zur Verf&uuml;gung.
            Einfach <a href="http://ipool.ba-berlin.de/m">http://ipool.ba-berlin.de/m</a> mit deinem Smartphone aufrufen!</p>
            <hr>
            <form action="/main.php" method="GET" name="timetable">
                <input type="hidden" name="action" value="browse_stundenplaene"> <span>Kurse:</span>
                <select name="faculty" onChange="on_faculty_change()">
                <option value="-1">Fachbereich w&auml;hlen</option><option value="0">Bank</option><option value="1">Bauwesen</option><option value="2">Dienstleistungsmanagement</option><option value="3">Elektrotechnik</option><option value="4">Facility Management</option><option value="5">Handel</option><option value="6">IBA</option><option value="7">Immobilienwirtschaft</option><option value="8">Industrie</option><option selected value="9">Informatik</option><option value="10">Maschinenbau</option><option value="11">PPM</option><option value="12">Spedition/Logistik</option><option value="13">Steuern/Prüfungswesen</option><option value="14">Tourismusbetriebswirtschaft</option><option value="15">Versicherung</option><option value="16">Wirtschaftsinformatik</option><option value="17">Externe Dozenten</option><option value="18">Bereich Technik (Laborplan)</option>                </select>
                <select id="form_tt_course" name="course" onChange="on_course_change()">
                <option value="-1">Kurs w&auml;hlen</option><option value="0">Semester 1</option><option value="1">Semester 2</option><option value="2">Semester 3</option><option selected value="3">Semester 4</option><option value="4">Semester 5</option><option value="5">Semester 6</option>                </select>
            </form>
            <div id="timetable_container">
            <ul class="inline_links">
<li><a href="stundenplaene.anzeige.php?faculty=9&amp;course=3&amp;type=html">Stundenplan&nbsp;herunterladen&nbsp;(HTML)</a></li><li><a href="stundenplaene.anzeige.php?faculty=9&amp;course=3&amp;type=ics">Stundenplan&nbsp;herunterladen&nbsp;(ICS)</a></li><li><a href="stundenplaene.anzeige.php?faculty=9&amp;course=3&amp;type=ics&amp;d=1&amp;ed=1503496024&amp;s=fa8cf1915d98289e0d932876e077520d9b37230d">ICS&nbsp;Direktlink (ohne&nbsp;Anmeldung - g&uuml;ltig&nbsp;sechs&nbsp;Monate)</a></li></ul><iframe class="timetable" src="stundenplaene.anzeige.php?faculty=9&amp;course=3&amp;type=inline"></iframe>            </div>
        </div>
    </div>
</div>
                </div>
    <div id="footer">
        <p>© 2001 - 2017 HWR Berlin, FB 2 - Duales Studium, FR Informatik</p>
    </div>
    </body>
</html>
    
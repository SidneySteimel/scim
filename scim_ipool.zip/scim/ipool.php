<!DOCTYPE html>
<html><head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>ipool</title>
<link rel="stylesheet" type="text/css" href="ipool.php-Dateien/default.css">
<script src="http://code.jquery.com/jquery-latest.js"></script>
<script src="ipool.js"></script>
<!--[if IE 6]>
<link rel="stylesheet" type="text/css" href="css/ie6.css">
<![endif]-->
<!--[if IE 7]>
<link rel="stylesheet" type="text/css" href="css/ie7.css">
<![endif]-->
    <script type="text/javascript">
function on_faculty_change() {
    if (document.timetable.faculty.selectedIndex > 0) {
        var fac = document.timetable.faculty.options[document.timetable.faculty.selectedIndex].value;
    	window.location.href = 'main.php?action=browse_stundenplaene&faculty='+fac;
    }
}

function on_course_change() {
    if ((document.timetable.faculty.selectedIndex > 0) && (document.timetable.course.selectedIndex > 0)) {
        var fac = document.timetable.faculty.options[document.timetable.faculty.selectedIndex].value;
        var crs = document.timetable.course.options[document.timetable.course.selectedIndex].value;
    	window.location.href = 'main.php?action=browse_stundenplaene&faculty='+fac+'&course='+crs;
    }
}
</script></head>
<body>
<div id="header">
    <a href="http://www.hwr-berlin.de/" target="_blank"><img id="logo" src="ipool.php-Dateien/hwr_logo.gif" alt="" height="57" width="249"></a>
    <h1>
        <a href="http://ipool.ba-berlin.de/main.php?menufb=0&amp;menukid=0&amp;menusem=0&amp;menuvl=0">iPool</a>
    </h1>
    <div id="top_nav">
        <div id="search">
            <form action="/main.php" method="GET">
                <label for="search_string">Suchen:</label> <span><input id="search_string" name="qry"> <input name="action" value="search_documents" type="hidden"> <input src="ipool.php-Dateien/magnifier_icon.png" alt="Suchen" type="image"> </span>
            </form>
        </div>
        <ul>
            <li><a href="http://ipool.ba-berlin.de/main.php?action=browse_stundenplaene"><img style="vertical-align:middle;" src="ipool.php-Dateien/icon_calendar.png"> Stundenpl�ne</a></li>
            <li><a href="http://ipool.ba-berlin.de/main.php?action=contact"><img style="vertical-align:middle;" src="ipool.php-Dateien/icon_letter.png"> Kontakt</a></li>
            <li><a href="http://ipool.ba-berlin.de/main.php?action=help"><img style="vertical-align:middle;" src="ipool.php-Dateien/icon_help.png"> Hilfe</a></li>
            <li><a href="http://ipool.ba-berlin.de/main.php?action=logout"><img style="vertical-align:middle;" src="ipool.php-Dateien/icon_logoff.png"> Logout</a> (angemeldet als:<em> <a href="http://ipool.ba-berlin.de/main.php?action=special">student</a></em>)</li>
        </ul>
    </div>
</div>
    <div id="page">
    <div id="nav">
        <!-- Navigationsmen� -->
    <div class="container">
<h2><a href="http://ipool.ba-berlin.de/main.php?menufb=0&amp;menukid=0&amp;menusem=0&amp;menuvl=0">Fachrichtungen</a></h2>
<div class="container_content">
<ul>
<li><a href="http://ipool.ba-berlin.de/main.php?menufb=15&amp;menukid=1&amp;menusem=0&amp;menuvl=0">Allgemein</a></li>
<li><a href="http://ipool.ba-berlin.de/main.php?menufb=17&amp;menukid=1&amp;menusem=0&amp;menuvl=0">BA weite VL'gen</a></li>
<li><a href="http://ipool.ba-berlin.de/main.php?menufb=1&amp;menukid=0&amp;menusem=0&amp;menuvl=0">Bank</a></li>
<li><a href="http://ipool.ba-berlin.de/main.php?menufb=2&amp;menukid=1&amp;menusem=0&amp;menuvl=0">Bauwesen</a></li>
<li><a href="http://ipool.ba-berlin.de/main.php?menufb=16&amp;menukid=1&amp;menusem=0&amp;menuvl=0">Dienstleistungsm.</a></li>
<li><a href="http://ipool.ba-berlin.de/main.php?menufb=18&amp;menukid=1&amp;menusem=0&amp;menuvl=0">Elektrotechnik</a></li>
<li><a href="http://ipool.ba-berlin.de/main.php?menufb=3&amp;menukid=0&amp;menusem=0&amp;menuvl=0">Handel</a></li>
<li><a href="http://ipool.ba-berlin.de/main.php?menufb=4&amp;menukid=0&amp;menusem=0&amp;menuvl=0">Immobilien</a></li>
<li><a href="http://ipool.ba-berlin.de/main.php?menufb=5&amp;menukid=0&amp;menusem=0&amp;menuvl=0">Industrie</a></li>
<li><a href="http://ipool.ba-berlin.de/main.php?menufb=6&amp;menukid=1&amp;menusem=0&amp;menuvl=0">Informatik</a></li>
<li><a href="http://ipool.ba-berlin.de/main.php?menufb=13&amp;menukid=1&amp;menusem=0&amp;menuvl=0">Internat. Studiengang</a></li>
<li><a href="http://ipool.ba-berlin.de/main.php?menufb=7&amp;menukid=1&amp;menusem=0&amp;menuvl=0">Maschinenbau</a></li>
<li><a href="http://ipool.ba-berlin.de/main.php?menufb=8&amp;menukid=1&amp;menusem=0&amp;menuvl=0">Spedition / Logistik</a></li>
<li><a href="http://ipool.ba-berlin.de/main.php?menufb=9&amp;menukid=0&amp;menusem=0&amp;menuvl=0">Steuern</a></li>
<li><a href="http://ipool.ba-berlin.de/main.php?menufb=14&amp;menukid=1&amp;menusem=0&amp;menuvl=0">Techn. Facility Management</a></li>
<li><a href="http://ipool.ba-berlin.de/main.php?menufb=10&amp;menukid=0&amp;menusem=0&amp;menuvl=0">Tourismus</a></li>
<li><a href="http://ipool.ba-berlin.de/main.php?menufb=11&amp;menukid=0&amp;menusem=0&amp;menuvl=0">Versicherung</a></li>
<li><a href="http://ipool.ba-berlin.de/main.php?menufb=12&amp;menukid=0&amp;menusem=0&amp;menuvl=0">Wirtschaftsinformatik</a></li>
</ul></div>
</div>
<div class="container">
<h2>Allgemeines</h2>
<div class="container_content">
<ul>
<li class="active"><a href="http://ipool.ba-berlin.de/main.php?action=browse_stundenplaene">Stundenpl�ne</a></li>
<li><a href="http://ipool.ba-berlin.de/main.php?action=browse_polls">Umfragen</a></li>
<li><a href="http://ipool.ba-berlin.de/main.php?action=mail_authorize">Mailbenachrichtigungen</a></li>
<li><a href="http://ipool.ba-berlin.de/bawiki" target="_blank">Ba-Wiki</a></li><li><a href="http://ipool.ba-berlin.de/main.php?action=search_documents&amp;mode=advanced">Dokumentensuche</a></li></ul>
</div>
</div>
</div>
<div class="content large">
    <div class="container">
        <h2>Stundenpl�ne</h2>
        <div class="container_content">
            <noscript>
                <p class="error">Bitte aktiviere JavaScript f&uuml;r die Stundenplanauswahl!</p>
            </noscript>
            <p>Unter [Allgemein] [Studiendekanat] [Informationen des
                Studiendekanats] kannst du dir eine <a href="http://ipool.ba-berlin.de/main.php?action=detailview&amp;fileno=28516&amp;menufb=15&amp;menukid=1&amp;menusem=10&amp;menuvl=1083">
                Erweiterung f�r die �bernahme der Termine (ics-Files) in den Outlook
                Kalender herunterladen</a>.</p>
            <p><strong>Neu:</strong> Ab sofort steht dir auch eine mobile Version deines Stundenplans zur Verf�gung.
            Einfach <a href="http://ipool.ba-berlin.de/m">http://ipool.ba-berlin.de/m</a> mit deinem Smartphone aufrufen!</p>
            <hr>
        <!-- Formular muss wieder in zwei Parte getrennte werden 
        ursrpüngliches Form tag :
        <form action="/main.php" method="GET" name="timetable">
        -->    
           <form id="scimForm" name="scimForm" method="POST" action="">
                <input name="action" value="browse_stundenplaene" type="hidden"> <span>Kurse:</span>
                <select id="form_tt_faculty" name="faculty" onchange="on_faculty_change()" >
                <option value="-1">Fachbereich w�hlen</option><option value="0">Bank</option><option value="1">Bauwesen</option><option value="2">Dienstleistungsmanagement</option><option value="3">Elektrotechnik</option><option value="4">Facility Management</option><option value="5">Handel</option><option value="6">IBA</option><option value="7">Immobilienwirtschaft</option><option value="8">Industrie</option><option selected="selected" value="9">Informatik</option><option value="10">Maschinenbau</option><option value="11">PPM</option><option value="12">Spedition/Logistik</option><option value="13">Steuern/Pr�fungswesen</option><option value="14">Tourismusbetriebswirtschaft</option><option value="15">Versicherung</option><option value="16">Wirtschaftsinformatik</option><option value="17">Externe Dozenten</option><option value="18">Bereich Technik (Laborplan)</option>                </select>
                <select id="form_tt_course" name="course" onchange="on_course_change()">
                <option value="-1">Kurs w�hlen</option><option value="0">Semester 1</option><option value="1">Semester 2</option><option value="2">Semester 3</option><option selected="selected" value="3">Semester 4</option><option value="4">Semester 5</option><option value="5">Semester 6</option>                </select>
           <!-- </form>-->
            <div id="timetable_container">
            <ul class="inline_links">
<li><a href="http://ipool.ba-berlin.de/stundenplaene.anzeige.php?faculty=9&amp;course=3&amp;type=html">Stundenplan&nbsp;herunterladen&nbsp;(HTML)</a></li>
<li><a href="http://ipool.ba-berlin.de/stundenplaene.anzeige.php?faculty=9&amp;course=3&amp;type=ics">Stundenplan&nbsp;herunterladen&nbsp;(ICS)</a></li>
<li><a href="http://ipool.ba-berlin.de/stundenplaene.anzeige.php?faculty=9&amp;course=3&amp;type=ics&amp;d=1&amp;ed=1503496024&amp;s=fa8cf1915d98289e0d932876e077520d9b37230d">ICS&nbsp;Direktlink (ohne&nbsp;Anmeldung - g�ltig&nbsp;sechs&nbsp;Monate)</a></li>
</ul>
<!--*****************************************************************************************************************************!--> 
<!--SCIM Code!--> 
<br/>
<div>  
<!--<form id="scimForm" name="scimForm" method="POST" action="">-->
<h4>Stundenplanänderung abonnieren</h4>
<p> Lieber iPool-Nutzer,</p>
<p>Sie können hier die Stundenplanänderungen für den ausgewählten Kurs abonnieren. Sobald eine Änderung vorliegt werden Sie eine E-Mail mit der entsprechenden Information erhalten. Aus Sicherheitstechnischen Gründen bitten wir Sie sich mit dem HWR-Login für den Dienst einzutragen.</p>
<div >
                            <label for="HWR-Mail">HWR-Mail:</label>
                            <input type="text"  placeholder="HWR-Mail"  name="HWR-Mail" id="HWR-Mail"  required> </input>
                        <br/>
                            <label for="Login-Passwort">Passwort : </label>
                            <input  type="password"  placeholder="Passwort"  name="password" id="Login-Passwort"  required></input>
                        </div>
                        <input type="submit"  value="Abonnieren"> </input>
 </form>
 </div> 
<!--php code zum Abfragen der Richtigkeit des Logins und eintragen in die Abo-Liste!
Die Werte faculty und course müssen dann über GET abgefragt werden--> 
<?php

if (!empty($_POST))
{ 
    // Erstellung der benötigen Variablen: 
switch ($_POST["faculty"])
    {
        case 0:
        $faculty = "bank";
            break;
        case 1:
        $faculty = "bauwesen";
            break;
        case 2:
        $faculty = "dienstleistungsmanagement";
            break;
        case 3:
        $faculty = "elektrotechnik";
            break;
        case 4:
        $faculty = "facilitymanagement";
            break;
        case 5:
        $faculty = "handel";
            break; 
        case 6:
        $faculty = "iba";
            break; 
        case 7:
        $faculty = "immobilienwirtschaft";
            break; 
        case 8:
        $faculty = "industrie";
            break; 
        case 9:
        $faculty = "informatik";
            break; 
        case 10:
        $faculty = "maschinenbau";
            break; 
        case 11:
        $faculty = "ppm";
            break; 
        case 12:
        $faculty = "speditionlogistik??";
            break; 
        case 13:
        $faculty = "??";
            break; 
        case 14:
        $faculty = "tourismusbetriebswirtschaft";
            break; 
        case 15:
        $faculty = "versicherung";
            break; 
        case 16:
        $faculty = "wirtschaftsinformatik";
            break; 
        case 17:
        $faculty = "externe_Dozenten";
            break; 
        case 18:
        $faculty = "_semester6";
            break; 
        default: 
            print_r("Kein Kurs ausgewählt");
    }
    switch ($_POST["course"])
    {
        case 0:
        $course = "_semester1_kurs";
            break;
        case 1:
        $course = "_semester2_kurs";
            break;
        case 2:
        $course = "_semester3_kurs";
            break;
        case 3:
        $course = "_semester4_kurs";
            break;
        case 4:
        $course = "_semester5_kurs";
            break;
        case 5:
        $course = "_semester6";  
            break; 
        default: 
            print_r("Kein Kurs ausgewählt");
    }
    
            $filePath=("mailingLists/".$faculty.$course . ".txt");
            $file = file_get_contents($filePath);
            $name= $_POST["HWR-Mail"];
            
    $url = 'https://webmail.stud.hwr-berlin.de/ajax/login?action=login';
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL, $url);
    curl_setopt($ch,CURLOPT_POST, true);
    curl_setopt($ch,CURLOPT_POSTFIELDS, http_build_query($_POST));
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $output = curl_exec($ch);
    $info = curl_getinfo($ch);

    if ($output === false || $info['http_code'] != 200) {
        $output = "No cURL data returned for $url [". $info['http_code']."]";
            if (curl_error($ch)){
                $output .= "\n". curl_error($ch);
               echo "Login fehlgeschlagen" ;
            }
        }
        else {
            // 'OK' status; format $output data if necessary here:
                if (strpos($name, '@')!==false){
              $mail = $_POST["HWR-Mail"] . "\r\n";
            }
            else{
                 $mail = $_POST["HWR-Mail"] . "@stud.hwr-berlin.de\r\n";

            }
           if (strpos($file, $mail)===false){
           
          file_put_contents($filePath , $mail, FILE_APPEND);
          print_r("Kurs wurde abonniert");
        }
         else 
        {echo "Sie abonnieren bereits die Stundenplanänderungen für diesen Kurs";}
        }
       
        
        curl_close($ch);
    }
    
    ?>



<iframe class="timetable" src="ipool.php-Dateien/stundenplaene.htm"></iframe>            </div>
        </div>    
    </div>
</div>
                </div>
    <div id="footer">
        <p>� 2001 - 2017 HWR Berlin, FB 2 - Duales Studium, FR Informatik</p>
    </div>
    

    </body></html>